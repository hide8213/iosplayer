// Copyright 2015 Google Inc. All rights reserved.

#import <Foundation/Foundation.h>

#import "HTTPConnection.h"

@interface LocalWebConnection : HTTPConnection
@end
